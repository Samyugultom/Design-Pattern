public class BurgerFactory {
    private final String jenis;
    private final int ukuran;
    private final String topping;

    // constructor untuk membuat objek burger dengan spesifikasi tertentu
    public BurgerFactory(String jenis, int ukuran, String topping) {
        this.jenis = jenis;
        this.ukuran = ukuran;
        this.topping = topping;
    }

    // metode untuk menampilkan informasi tentang burger
    public void tampilkanBurger() {
        System.out.println("Jenis burger: " + jenis);
        System.out.println("Ukuran burger: " + ukuran);
        System.out.println("Topping burger: " + topping);
    }

    public static BurgerFactory createBurger(String jenis) {
        BurgerFactory burger = null;
        if (jenis.equalsIgnoreCase("Burger Ayam")) {
            burger = new BurgerFactory("Burger Ayam", 1, "jamur dan keju");
        } else if (jenis.equalsIgnoreCase("Burger Ikan")) {
            burger = new BurgerFactory("Burger Ikan", 2, "daging dan sosis");
        } else if (jenis.equalsIgnoreCase("Burger Kambing")) {
            burger = new BurgerFactory("Burger Kambing", 3, "ikan dan bakso");
        }
        return burger;
    }

    public static void main(String[] args) {
        BurgerFactory burger1 = BurgerFactory.createBurger("Burger Ayam");
        burger1.tampilkanBurger();

        BurgerFactory burger2 = BurgerFactory.createBurger("Burger Ikan");
        burger2.tampilkanBurger();

        BurgerFactory burger3 = BurgerFactory.createBurger("Burger Kambing");
        burger3.tampilkanBurger();
    }
}




